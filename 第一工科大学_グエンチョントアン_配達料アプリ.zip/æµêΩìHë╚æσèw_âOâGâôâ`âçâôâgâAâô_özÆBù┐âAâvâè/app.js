//配達料を定義する
const ARRAY_GIA_UBER = [300, 200, 300];
const GIA_CHO_UBER = 200;//待ち料金

const ARRAY_GIA_DiDiFood = [350, 250, 400];
const GIA_CHO_DiDiFood = 300;//待ち料金

const ARRAY_GIA_MENU = [450, 300, 450];
const GIA_CHO_MENU = 300;//待ち料金

function kiemTraLoaiXe(){
    var ubereats = document.getElementById("ubereats");
    var didiFood = document.getElementById("didiFood");
    var menu = document.getElementById("menu");

    if(ubereats.checked){
        return "ubereats";
    } else if(didiFood.checked){
        return "didiFood"
    } else if(menu.checked){
        return "menu";
    }
}
//配達員は一回３分待つなら、配達料＝元配達料+待ち料
function tinhTienCho(thoiGianCho, giaCho){
    var tienCho = 0; 
    if(thoiGianCho >=3){
        tienCho = Math.round(thoiGianCho/3.0) * giaCho;
    }
    return tienCho;
}

function tinhTien(soKm, thoiGianCho, arrayPrice, giaCho){
    var tienCho = tinhTienCho(thoiGianCho, giaCho);
    if(soKm <=1){
        return arrayPrice[0] + tienCho;
    } else if(soKm > 1 && soKm <=5){
        return arrayPrice[0] + (soKm - 1) * arrayPrice[1] + tienCho;
    } else if(soKm > 5){
        return arrayPrice[0] + 4*arrayPrice[1] * (soKm -5) *arrayPrice[2] + tienCho;
    }
    
}

function tinhTongTien(){
    var soKM = document.getElementById("soKM").value;
    var thoiGianCho = document.getElementById("thoiGianCho").value;

    soKM = parseFloat(soKM);
    thoiGianCho = parseFloat(thoiGianCho);

    var tongTien = 0; 
    var loaiXe = kiemTraLoaiXe();
    switch(loaiXe){
        case "ubereats": 
            tongTien = tinhTien(soKM,thoiGianCho, ARRAY_GIA_UBER, GIA_CHO_UBER);
        break;
        case "didiFood": 
             tongTien = tinhTien(soKM,thoiGianCho, ARRAY_GIA_DiDiFood, GIA_CHO_DiDiFood);
        break;
        case "menu": 
             tongTien = tinhTien(soKM,thoiGianCho, ARRAY_GIA_MENU, GIA_CHO_MENU);
        break;
        default:
            alert("配達アプリを選択してください");
    }
    return tongTien;
}

document.getElementById("btnTinhTien").onclick = function (){
    var tongTien = tinhTongTien();
    document.getElementById("divThanhTien").style.display = "block";
    document.getElementById("xuatTien").innerHTML = tongTien;
}

function renderRowChiTietKm(loaiXe, arrayKm, arrayPrice, tblBody){
    for(var i = 0; i <arrayKm.length; i++){
        var tr = document.createElement("tr");

        var tdLoaiXe = document.createElement("td");
        var tdSuDung = document.createElement("td");
        var tdDongGia = document.createElement("td");
        var tdThanhTien = document.createElement("td");

        tdLoaiXe.innerHTML = loaiXe;
        tdSuDung.innerHTML = arrayKm[i] + " km";
        tdDongGia.innerHTML = arrayPrice[i];
        tdThanhTien.innerHTML = arrayKm[i] * arrayPrice[i];

        tr.appendChild(tdLoaiXe);
        tr.appendChild(tdSuDung);
        tr.appendChild(tdDongGia);
        tr.appendChild(tdThanhTien);

        tblBody.appendChild(tr);
    }
}

function renderRowThoiGianCho(thoiGianCho, giaCho, tblBody){
    var tienCho = tinhTienCho(thoiGianCho, giaCho);
    var trThoiGianCho = document.createElement("tr");

    var tdPhutTitle = document.createElement("td");
    var tdPhut = document.createElement("td");
    var tdDongGia = document.createElement("td");
    var tdThanhTien = document.createElement("td");

    tdPhutTitle.innerHTML = " 待ち時間";
    tdPhutTitle.innerHTML = thoiGianCho + " 分";
    tdDongGia.innerHTML = giaCho;
    tdThanhTien.innerHTML = tienCho;

    trThoiGianCho.appendChild(tdPhutTitle);
    trThoiGianCho.appendChild(tdPhut);
    trThoiGianCho.appendChild(tdDongGia);
    trThoiGianCho.appendChild(tdThanhTien);

    tblBody.appendChild(trThoiGianCho);
}

function renderRowTongCong(tongTien, tblBody){
    var trTotal = document.createElement("tr");
    trTotal.className = "alert alert-success";

    var tdTotalTile = document.createElement("td");
    tdTotalTile.setAttribute("colspan", 3);
    var tdTotal = document.createElement("td");

    tdTotalTile.innerHTML = "合計";
    tdTotal.innerHTML = tongTien;

    trTotal.appendChild(tdTotalTile);
    trTotal.appendChild(tdTotal);

    tblBody.appendChild(trTotal);
}

function inHoaDon(loaiXe, soKm, thoiGianCho, giaCho, arrayPrice, tongTien){
    var tblBody = document.getElementById("tblBody");
    tblBody.innerHTML = ""; // reset lại tbody 

    if(soKm <=1){
        renderRowChiTietKm(loaiXe,[1], arrayPrice, tblBody);
    } 
    else if(soKm > 1 && soKm <=5){
        renderRowChiTietKm(loaiXe, [1, soKm -1], arrayPrice, tblBody);
    } 
    else if(soKm > 5){
        renderRowChiTietKm(loaiXe, [1, 4, soKm - 5], arrayPrice, tblBody);
    }

    /**
     * Thời gian chờ
     */
    if(thoiGianCho > 2){
        renderRowThoiGianCho(thoiGianCho, giaCho, tblBody);
    }

    /**
     * Tổng tiền
     */
    renderRowTongCong(tongTien, tblBody);
}

document.getElementById("btnInHD").onclick = function(){
    var kq = getData();
    var tongTien = tinhTongTien();
    var loaiXe = kiemTraLoaiXe();
    switch(loaiXe){
        case "ubereats":
            inHoaDon(loaiXe, kq[0], kq[1], GIA_CHO_UBER,ARRAY_GIA_UBER, tongTien);
        break;
        case "didiFood":
            inHoaDon(loaiXe, kq[0], kq[1], GIA_CHO_DiDiFood,ARRAY_GIA_DiDiFood, tongTien);
        break;
        case "menu":
            inHoaDon(loaiXe, kq[0], kq[1],GIA_CHO_MENU ,ARRAY_GIA_MENU, tongTien);
        break;
        default:
            alert("配達アプリを選択してください");    
    }


}

function getData(){
    var kq = [];
    var soKm = document.getElementById("soKM").value;
    soKm = parseFloat(soKm);
    kq.push(soKm);
    var thoiGianCho = document.getElementById("thoiGianCho").value;
    thoiGianCho = parseFloat(thoiGianCho);
    kq.push(thoiGianCho);
    return kq;
}